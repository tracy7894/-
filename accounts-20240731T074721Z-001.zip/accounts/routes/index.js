var express = require('express');
var router = express.Router();

const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync');
const shortid = require('shortid');
 
const adapter = new FileSync(__dirname+'/../data/db.json')
const db = low(adapter)


/* GET home page. */
router.get('/account', function(req, res, next) {
  let accounts=db.get('accounts').value()
  console.log(accounts)
  res.render('list',{accounts:accounts})
  //res.render('index', { title: 'Express' });
});
router.get('/account/create', function(req, res, next) {
  res.render('create')
  //res.render('index', { title: 'Express' });
});
router.post('/account',(req,res)=>{
  let id=shortid.generate()
  //console.log(req.body)
  db.get('accounts').push({id:id,...req.body}).write()
  // res.send('新增紀錄')
  res.render('success',{msg:'新增成功',url:'/account'})
})
router.get('/account/:id',(req,res)=>{
  let id=req.params.id
  db.get('accounts').remove({id:id}).write()
  res.render('success',{msg:'刪除成功',url:'/account'})
})

module.exports = router;
